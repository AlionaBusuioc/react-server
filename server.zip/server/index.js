const express = require('express')
const fs = require('fs')
const app = express()
const port = 3000


//RESTFULL routing 

//###################### CONTROLERS ############################### req - ce vine de la client, res - ce pleaca la client
const productIndex = (req, res) => {
    //calback-urile legate de date - (err,data); 
    fs.readFile('./database/products.json', (err,data)=> {
        if(!err){
            let products = JSON.parse(data)
            let product = products.find ( p => p.id == req.params.productid) 
            console.log(product);
            // console.log(products.find( p => p.id == req.params.productid));
            // res.append('Content-type', 'image/png')
            res.append('Content-type', 'application/json')
            res.send (product)
        }
    });
}
const productDetails = (req, res) => {

console.log(req.params.productid);

    //calback-urile legate de date - (err,data); 
    fs.readFile('./database/products.json', (err,data)=> {
        if(!err){
            let products = JSON.parse(data)
            let product = products.find ( p => p.id == req.params.productid) 
            console.log(product);
            // console.log(products.find( p => p.id == req.params.productid));
            // res.append('Content-type', 'image/png')
            res.append('Content-type', 'application/json')
            res.send (product)
        }
    });
    // fs.readFile('./database/products.json', (err,data)=> {
    //     if(!err){
    //         // console.log(data);
    //         // res.append('Content-type', 'image/png')
    //         res.append('Content-type', 'application/json')
    //         res.send (data.toString())
    //     }
    // });
}
const productDelete = (req, res) => {

    console.log(req.params.productid);
    
        //calback-urile legate de date - (err,data); 
        // fs.readFile('./database/products.json', (err,data)=> {
        //     if(!err){
        //         let products = JSON.parse(data)
        //         let product = products.find ( p => p.id == req.params.productid) 
        //         console.log(product);
                // console.log(products.find( p => p.id == req.params.productid));
                // res.append('Content-type', 'image/png')
        //         res.append('Content-type', 'application/json')
        //         res.send (product)
        //     }
        // });
        // fs.readFile('./database/products.json', (err,data)=> {
        //     if(!err){
        //         // console.log(data);
        //         // res.append('Content-type', 'image/png')
        //         res.append('Content-type', 'application/json')
        //         res.send (data.toString())
        //     }
        // });
    }

//###################### CONTROLERS ###############################
app.get('/products', productIndex)
app.get('/products/:productid', productDetails)
app.delete('/products/:productid', productDelete)
//###################### CONTROLERS ###############################
app.listen(port, () => console.log(`Example app listening on port ${port}!`))